GY-NEXUS AFFILIATE IMAGE FIX V4

This version does not put JSX or CSS inside PowerShell.
Node.js reads and writes every source file as UTF-8.

CHANGES
- Resolve affiliate short links.
- Extract product name, description, price, discount and representative image.
- Copy permitted remote product images into Supabase Storage when possible.
- Keep the original affiliate URL.
- Add direct JPG, PNG and WEBP image upload.
- Add an AI product-image workspace shortcut.
- Back up the three original source files before changing them.

RECOMMENDED RUN
1. Extract this folder inside the GY-NEXUS project.
2. Open PowerShell in the GY-NEXUS project.
3. Run:
   node .\_AFFILIATE_IMAGE_FIX_V4\GY-NEXUS-AFFILIATE-IMAGE-FIX-V4\apply-affiliate-image-fix.mjs --repo .

Then run:
npm run typecheck
npm run build
