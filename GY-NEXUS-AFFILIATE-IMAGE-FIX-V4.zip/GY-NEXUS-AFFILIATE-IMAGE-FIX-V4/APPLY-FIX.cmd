@echo off
cd /d "%~dp0"
node apply-affiliate-image-fix.mjs --repo "%CD%\.."
pause
