﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0apply-shorts-hub-v3.ps1"
set "RESULT=%ERRORLEVEL%"

if not "%RESULT%"=="0" (
  echo.
  echo 적용에 실패했으며 이번 변경은 자동 복구되었습니다.
  echo 표시된 build.log의 마지막 오류를 보내주세요.
  pause
  exit /b %RESULT%
)

echo.
echo 적용과 빌드 검증이 완료되었습니다.
echo GitHub Desktop에서 Commit 후 Push하세요.
echo.
pause

del /q "%~dp0README-KR.md" >nul 2>nul
del /q "%~dp0MANIFEST.txt" >nul 2>nul
del /q "%~dp0apply-shorts-hub-v3.ps1" >nul 2>nul
(goto) 2>nul & del "%~f0"
