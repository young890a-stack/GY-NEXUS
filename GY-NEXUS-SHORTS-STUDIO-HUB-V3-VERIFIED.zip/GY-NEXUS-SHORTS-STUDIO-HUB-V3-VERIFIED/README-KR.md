# GY-NEXUS 통합 쇼츠 제작실 V3

이번 버전은 새롭고 불안정한 AI API를 추가하지 않습니다.

현재 GY-NEXUS에 이미 존재하는 `Content Factory` API를 사용해 다음 결과를 만듭니다.

- 한국형 쇼츠 제목
- 첫 2초 훅
- 전체 한국어 대본
- 초 단위 장면표
- 정확한 한국어 SRT
- 썸네일 문구와 이미지 프롬프트
- SEO 키워드
- YouTube 설명과 고정댓글
- CapCut·Movavi 편집 가이드
- 미리캔버스 디자인 패키지

## 최상단 메뉴

1. 통합 쇼츠 제작실
2. 블로그 제작실
3. 상품 관리

중복된 쇼츠 메뉴는 사이드바에서 제거하지만 기존 기능 코드는 보존합니다.

통합 쇼츠 제작실 안에서 다음으로 이동할 수 있습니다.

- 중국 쇼핑 숏폼 제작실
- Creative Studio Pro 자동 MP4 제작실
- Gemini
- AlphaCut
- Runway
- Google Trends
- vidIQ
- TubeBuddy
- 미리캔버스
- Canva
- CapCut
- Movavi
- DaVinci Resolve
- YouTube 오디오 라이브러리
- Epidemic Sound
- YouTube Studio
- Social Blade

## 미리캔버스 연동 방식

미리캔버스의 일반 사용자를 위한 공개 디자인 생성 API는 확인되지 않았습니다.

따라서 계정 비밀번호를 저장하거나 가짜 OAuth 버튼을 만들지 않습니다.

GY-NEXUS가 다음 항목을 한 번에 복사해 미리캔버스를 엽니다.

- 1080×1920 쇼츠 커버 규격
- 1280×720 유튜브 썸네일 규격
- 핵심 썸네일 문구
- 한글 배치와 디자인 지시
- AI 이미지 프롬프트
- 과장광고 방지 조건

## 적용 방법

1. 압축을 풉니다.
2. 압축 폴더를 아래 프로젝트 폴더 안에 넣습니다.

```text
C:\Users\홍영택\Documents\GitHub\GY-NEXUS
```

3. 아래 파일을 더블클릭합니다.

```text
1-통합쇼츠제작실V3적용.bat
```

스크립트가 자동으로 처리합니다.

- 이전 실패한 한국형 쇼츠 파일 백업 및 정리
- 새 통합 쇼츠 제작실 설치
- 중복 사이드바 메뉴 정리
- `.next` 캐시 삭제
- 실제 `npm run build`
- 빌드 실패 시 V3 변경 자동 원상 복구
- 오류 로그 저장

빌드 성공 후 GitHub Desktop에서 Commit 후 Push합니다.

추천 커밋:

```text
Add verified all-in-one Shorts production hub
```

## 검증 범위

새 TypeScript·TSX 파일은 별도의 엄격한 TypeScript 검사에서 오류 없이 통과했습니다.

최종 Next.js 프로덕션 빌드는 대표님 프로젝트의 실제 환경변수와 설치된 패키지를 사용해 적용 스크립트가 직접 검사합니다. 실패하면 원본을 자동 복구합니다.
