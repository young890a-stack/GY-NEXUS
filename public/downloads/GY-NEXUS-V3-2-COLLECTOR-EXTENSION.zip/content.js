(() => {
  let running = false;
  const seen = new Map();

  function platform() {
    const host = location.hostname.toLowerCase();
    if (host.includes("douyin.com")) return "douyin";
    if (host.includes("xiaohongshu.com") || host.includes("xhslink.com")) return "xiaohongshu";
    return null;
  }

  function absoluteUrl(value) {
    try { return new URL(value, location.href).toString().split("#")[0]; } catch { return ""; }
  }

  function externalId(url, currentPlatform) {
    const patterns = currentPlatform === "douyin" ? [/\/video\/(\d+)/, /\/note\/(\d+)/] : [/\/explore\/([a-zA-Z0-9]+)/, /\/discovery\/item\/([a-zA-Z0-9]+)/];
    for (const pattern of patterns) { const match = url.match(pattern); if (match) return match[1]; }
    return null;
  }

  function labeledCount(text, labels) {
    for (const label of labels) {
      const match = text.match(new RegExp(`${label}\\s*[:：]?\\s*([0-9.,]+(?:万|w|W|k|K)?)`));
      if (!match) continue;
      const raw = match[1].replace(/,/g, "");
      const number = Number.parseFloat(raw);
      if (!Number.isFinite(number)) return null;
      if (/万/.test(raw)) return Math.round(number * 10000);
      if (/[wW]/.test(raw)) return Math.round(number * 10000);
      if (/[kK]/.test(raw)) return Math.round(number * 1000);
      return Math.round(number);
    }
    return null;
  }

  function cardFromAnchor(anchor, currentPlatform, rank, keyword) {
    const url = absoluteUrl(anchor.getAttribute("href") || "");
    const id = externalId(url, currentPlatform);
    if (!url || !id) return null;
    const container = anchor.closest("article,li,section") || anchor.parentElement?.parentElement || anchor.parentElement || anchor;
    const text = String(container.innerText || anchor.innerText || "").replace(/\s+/g, " ").trim().slice(0, 1200);
    const image = container.querySelector("img") || anchor.querySelector("img");
    const title = String(image?.alt || anchor.getAttribute("title") || text || `${currentPlatform} 공개 카드`).replace(/\s+/g, " ").trim().slice(0, 300);
    const previous = seen.get(url) || 0;
    seen.set(url, previous + 1);
    return {
      platform: currentPlatform,
      externalId: id,
      url,
      title,
      author: null,
      thumbnailUrl: image?.currentSrc || image?.src || null,
      views: labeledCount(text, ["播放", "观看", "浏览"]),
      likes: labeledCount(text, ["点赞", "获赞"]),
      comments: labeledCount(text, ["评论"]),
      saves: labeledCount(text, ["收藏"]),
      shares: labeledCount(text, ["分享", "转发"]),
      searchRank: rank,
      repeatedExposureCount: previous + 1,
      keywordHits: keyword ? [keyword] : [],
      sourceMode: "account-assisted",
      rawData: { visibleText: text, collectedFrom: location.href, collectedAt: new Date().toISOString() },
    };
  }

  function collectVisible(currentPlatform, keyword) {
    const selector = currentPlatform === "douyin"
      ? 'a[href*="/video/"],a[href*="/note/"]'
      : 'a[href*="/explore/"],a[href*="/discovery/item/"]';
    const anchors = Array.from(document.querySelectorAll(selector));
    return anchors.map((anchor, index) => cardFromAnchor(anchor, currentPlatform, index + 1, keyword)).filter(Boolean);
  }

  function updateProgress(progress) {
    chrome.storage.local.set({ gyCollectorProgress: { ...progress, updatedAt: new Date().toISOString() } });
  }

  function upload(config, currentPlatform, keyword, candidates) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: "GY_UPLOAD_BATCH", payload: { ...config, platform: currentPlatform, keyword, candidates } }, (response) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!response?.success) return reject(new Error(response?.message || "업로드 실패"));
        resolve(response.data);
      });
    });
  }

  async function start(config) {
    if (running) throw new Error("이미 수집 중입니다.");
    const currentPlatform = platform();
    if (!currentPlatform) throw new Error("도우인 또는 샤오홍슈 검색 결과 페이지에서 실행해주세요.");
    if (!config?.collectorToken || !config?.apiBase) throw new Error("GY-NEXUS 수집 연결 설정이 필요합니다.");
    running = true;
    let uploadedUrls = new Set();
    let noNewRounds = 0;
    let serverTotal = 0;
    try {
      updateProgress({ running: true, platform: currentPlatform, keyword: config.keyword || "", localFound: 0, serverTotal: 0, message: "수집 시작" });
      for (let round = 0; round < 80; round += 1) {
        const cards = collectVisible(currentPlatform, config.keyword || "");
        const fresh = cards.filter((item) => !uploadedUrls.has(item.url)).slice(0, 50);
        if (fresh.length) {
          fresh.forEach((item) => uploadedUrls.add(item.url));
          const result = await upload(config, currentPlatform, config.keyword || "", fresh);
          serverTotal = Number(result.total || serverTotal);
          noNewRounds = 0;
          updateProgress({ running: true, platform: currentPlatform, keyword: config.keyword || "", localFound: uploadedUrls.size, serverTotal, target: result.target, message: `서버 저장 ${serverTotal}/${result.target}` });
          if (result.completed || serverTotal >= Number(config.target || 300)) break;
        } else {
          noNewRounds += 1;
        }
        if (noNewRounds >= 8) break;
        window.scrollBy({ top: Math.max(700, window.innerHeight * 0.85), behavior: "smooth" });
        await new Promise((resolve) => setTimeout(resolve, 1300));
      }
      updateProgress({ running: false, completed: true, platform: currentPlatform, keyword: config.keyword || "", localFound: uploadedUrls.size, serverTotal, message: `현재 검색어 수집 완료 · 서버 누적 ${serverTotal}` });
      return { localFound: uploadedUrls.size, serverTotal };
    } catch (error) {
      updateProgress({ running: false, completed: false, error: error.message || String(error), message: "수집 중단" });
      throw error;
    } finally { running = false; }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== "GY_COLLECT_START") return;
    start(message.config).then((result) => sendResponse({ success: true, result })).catch((error) => sendResponse({ success: false, message: error.message || String(error) }));
    return true;
  });
})();
