chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "GY_UPLOAD_BATCH") return;
  const { apiBase, collectorToken, platform, keyword, candidates } = message.payload || {};
  fetch(`${String(apiBase || "").replace(/\/$/, "")}/api/shorts-intelligence-v3/collector-ingest`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-GY-Collector-Token": collectorToken },
    body: JSON.stringify({ platform, keyword, candidates }),
  }).then(async (response) => {
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.success) throw new Error(data.message || `HTTP ${response.status}`);
    sendResponse({ success: true, data });
  }).catch((error) => sendResponse({ success: false, message: error.message || String(error) }));
  return true;
});
