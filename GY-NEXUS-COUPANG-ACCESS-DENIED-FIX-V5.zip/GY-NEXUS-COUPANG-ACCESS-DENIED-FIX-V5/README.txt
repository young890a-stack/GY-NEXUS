GY-NEXUS COUPANG ACCESS DENIED FIX V5

What this fixes
- Detects Coupang Access Denied, CloudFront block and HTTP 401/403 pages.
- Never writes "Access Denied" into the product name field.
- Extracts the Coupang product ID from /vp/products/{productId}.
- Uses the existing Coupang Partners HMAC API connection first.
- Uses the API product name, price, product image and affiliate URL.
- Clears stale product values when automatic lookup fails.
- Keeps direct image upload and AI-image fallback available.
- Backs up all three changed files.

Run from the GY-NEXUS project:
node .\_COUPANG_ACCESS_DENIED_FIX_V5\GY-NEXUS-COUPANG-ACCESS-DENIED-FIX-V5\apply-coupang-access-denied-fix.mjs --repo .

Then:
npm run typecheck
npm run build
