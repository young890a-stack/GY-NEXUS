import fs from "node:fs";
import path from "node:path";
import process from "node:process";

function argument(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : "";
}

function isRepoRoot(folder) {
  return fs.existsSync(path.join(folder, "package.json"))
    && fs.existsSync(path.join(folder, "app"))
    && fs.existsSync(path.join(folder, "components"));
}

function findRepoRoot() {
  const requested = argument("--repo");
  const candidates = [
    requested,
    process.cwd(),
    path.dirname(new URL(import.meta.url).pathname),
    path.resolve(path.dirname(new URL(import.meta.url).pathname), ".."),
    path.resolve(path.dirname(new URL(import.meta.url).pathname), "../.."),
  ].filter(Boolean).map((item) => decodeURIComponent(item));

  for (const candidate of candidates) {
    const resolved = path.resolve(candidate);
    if (isRepoRoot(resolved)) return resolved;
  }
  throw new Error("GY-NEXUS project root was not found. Run this inside the GY-NEXUS folder.");
}

function normalize(value) {
  return value.replace(/\r\n/g, "\n");
}

function writeUtf8(file, content) {
  fs.writeFileSync(file, content, { encoding: "utf8" });
}

function replaceOrSkip(text, oldText, newText, label) {
  if (text.includes(newText)) {
    console.log(`[SKIP] ${label} is already applied.`);
    return text;
  }
  if (!text.includes(oldText)) {
    throw new Error(`Patch location not found: ${label}. The repository file may have changed.`);
  }
  console.log(`[OK] ${label}`);
  return text.replace(oldText, newText);
}

const repoRoot = findRepoRoot();
const scriptRoot = path.dirname(decodeURIComponent(new URL(import.meta.url).pathname));
const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
const backupRoot = path.join(repoRoot, `.gy-backup-affiliate-image-v3-${timestamp}`);

const routePath = path.join(repoRoot, "app/api/revenue-shorts/product-import/route.ts");
const componentPath = path.join(repoRoot, "components/revenue-shorts/RevenueShortsCommandCenter.tsx");
const cssPath = path.join(repoRoot, "components/revenue-shorts/RevenueShortsCommandCenter.module.css");
const payloadRoute = path.join(scriptRoot, "payload/app/api/revenue-shorts/product-import/route.ts");

for (const file of [routePath, componentPath, cssPath, payloadRoute]) {
  if (!fs.existsSync(file)) throw new Error(`Required file not found: ${file}`);
}

fs.mkdirSync(path.dirname(path.join(backupRoot, "app/api/revenue-shorts/product-import/route.ts")), { recursive: true });
fs.mkdirSync(path.dirname(path.join(backupRoot, "components/revenue-shorts/RevenueShortsCommandCenter.tsx")), { recursive: true });

fs.copyFileSync(routePath, path.join(backupRoot, "app/api/revenue-shorts/product-import/route.ts"));
fs.copyFileSync(componentPath, path.join(backupRoot, "components/revenue-shorts/RevenueShortsCommandCenter.tsx"));
fs.copyFileSync(cssPath, path.join(backupRoot, "components/revenue-shorts/RevenueShortsCommandCenter.module.css"));

fs.copyFileSync(payloadRoute, routePath);

let component = normalize(fs.readFileSync(componentPath, "utf8"));
component = replaceOrSkip(component, "type ImportedProduct = {\n  name: string;\n  description: string;\n  imageUrl: string;\n  priceText: string;\n  platform: string;\n  finalUrl: string;\n  source: \"database\" | \"page-metadata\" | \"link-only\";\n  warning?: string;\n};", "type ImportedProduct = {\n  name: string;\n  description: string;\n  imageUrl: string;\n  originalImageUrl?: string;\n  imageStored?: boolean;\n  imageSource?: \"storage\" | \"remote\" | \"none\";\n  priceText: string;\n  discountText?: string;\n  platform: string;\n  finalUrl: string;\n  resolvedUrl?: string;\n  source: \"database\" | \"page-metadata\" | \"link-only\";\n  warning?: string;\n};", "ImportedProduct type");
component = replaceOrSkip(component, "  const [productImageUrl, setProductImageUrl] = useState(\"\");\n  const [priceText, setPriceText] = useState(\"\");", "  const [productImageUrl, setProductImageUrl] = useState(\"\");\n  const [imageLoadFailed, setImageLoadFailed] = useState(false);\n  const [priceText, setPriceText] = useState(\"\");", "product image state");
component = replaceOrSkip(component, "      if (product.imageUrl) setProductImageUrl(product.imageUrl);\n      if (product.priceText) setPriceText(product.priceText);", "      if (product.imageUrl) {\n        setProductImageUrl(product.imageUrl);\n        setImageLoadFailed(false);\n      }\n      if (product.priceText) {\n        setPriceText(product.discountText ? `${product.priceText} · ${product.discountText} 할인` : product.priceText);\n      }", "imported product setters");
component = replaceOrSkip(component, "      setStatus(product.warning || `상품 정보를 불러왔습니다. 중국 검색어 ${keyword}도 준비했습니다.`);", "      const imageStatus = product.imageStored\n        ? \"대표 이미지도 GY 저장소에 복사했습니다.\"\n        : product.imageUrl\n          ? \"대표 이미지는 외부 주소로 확인했습니다. 화면에서 깨지면 직접 업로드해주세요.\"\n          : \"대표 이미지를 찾지 못했습니다. 직접 업로드 또는 AI 이미지 생성으로 보완해주세요.\";\n      setStatus(product.warning || `상품 정보를 불러왔습니다. ${imageStatus} 중국 검색어 ${keyword}도 준비했습니다.`);", "image storage status");

const uploadFunction = "\n  async function uploadProductImage(file: File | undefined) {\n    if (!file) return;\n    if (![\"image/jpeg\", \"image/png\", \"image/webp\"].includes(file.type)) {\n      setError(\"상품 이미지는 JPG, PNG, WEBP 형식만 사용할 수 있습니다.\");\n      return;\n    }\n    if (file.size < 1 || file.size > 8 * 1024 * 1024) {\n      setError(\"상품 이미지는 8MB 이하여야 합니다.\");\n      return;\n    }\n    setBusy(\"product-image-upload\");\n    setError(\"\");\n    setStatus(\"상품 이미지를 GY 저장소에 업로드하고 있습니다.\");\n    try {\n      const form = new FormData();\n      form.append(\"images\", file);\n      const response = await fetch(\"/api/creative-studio-pro/references\", { method: \"POST\", body: form });\n      const data = await response.json() as { success?: boolean; urls?: string[]; message?: string };\n      if (!response.ok || !data.success || !data.urls?.[0]) throw new Error(data.message || \"상품 이미지 업로드 실패\");\n      setProductImageUrl(data.urls[0]);\n      setImageLoadFailed(false);\n      setStatus(\"상품 이미지를 GY 저장소에 안전하게 저장했습니다.\");\n    } catch (cause) {\n      setError(cause instanceof Error ? cause.message : \"상품 이미지 업로드 실패\");\n    } finally {\n      setBusy(\"\");\n    }\n  }";
const prepareMarker = "\n  async function prepareChineseSearch() {";
if (component.includes("async function uploadProductImage(")) {
  console.log("[SKIP] direct image upload function is already applied.");
} else {
  if (!component.includes(prepareMarker)) {
    throw new Error("Patch location not found: direct image upload function.");
  }
  component = component.replace(prepareMarker, uploadFunction + prepareMarker);
  console.log("[OK] direct image upload function");
}

component = replaceOrSkip(component, "        <div className={styles.productGrid}>\n          <div className={styles.productPreview}>\n            {productImageUrl ? <img src={productImageUrl} alt={productName || \"상품 이미지\"} /> : <div><strong>상품 이미지</strong><span>제휴링크에서 자동 수집</span></div>}\n          </div>\n          <div className={styles.productFields}>\n            <label><span>상품명</span><input value={productName} onChange={(event: ChangeEvent<HTMLInputElement>) => setProductName(event.target.value)} placeholder=\"상품명\" /></label>\n            <label><span>가격</span><input value={priceText} onChange={(event: ChangeEvent<HTMLInputElement>) => setPriceText(event.target.value)} placeholder=\"자동 확인 또는 직접 입력\" /></label>\n            <label className={styles.wide}><span>상품 설명·판매 포인트</span><textarea value={productDescription} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => setProductDescription(event.target.value)} placeholder=\"상품 설명과 실제 장점\" /></label>\n            <label><span>판매 플랫폼</span><input value={platform} onChange={(event: ChangeEvent<HTMLInputElement>) => setPlatform(event.target.value)} placeholder=\"coupang / temu / naver\" /></label>\n            <label><span>중국어 검색어</span><input value={chineseKeyword} onChange={(event: ChangeEvent<HTMLInputElement>) => setChineseKeyword(event.target.value)} placeholder=\"예: 手持小风扇\" /></label>\n          </div>\n        </div>", "        <div className={styles.productGrid}>\n          <div className={styles.productPreview}>\n            <div className={styles.productPreviewMedia}>\n              {productImageUrl && !imageLoadFailed\n                ? <img src={productImageUrl} alt={productName || \"상품 이미지\"} onError={() => { setImageLoadFailed(true); setStatus(\"외부 상품 이미지 표시가 차단됐습니다. 아래 직접 업로드를 사용해주세요.\"); }} />\n                : <div><strong>상품 이미지</strong><span>{productImageUrl ? \"외부 이미지 표시 실패\" : \"제휴링크에서 자동 수집\"}</span></div>}\n            </div>\n            <div className={styles.imageFallbackActions}>\n              <label className={styles.imageUploadButton}>\n                <input type=\"file\" accept=\"image/jpeg,image/png,image/webp\" onChange={(event: ChangeEvent<HTMLInputElement>) => void uploadProductImage(event.target.files?.[0])} />\n                <span>{busy === \"product-image-upload\" ? \"이미지 저장 중...\" : \"상품 이미지 직접 업로드\"}</span>\n              </label>\n              <a href=\"/admin/creative-studio-pro\" target=\"_blank\" rel=\"noreferrer\">AI 상품 이미지 만들기</a>\n            </div>\n          </div>\n          <div className={styles.productFields}>\n            <label><span>상품명</span><input value={productName} onChange={(event: ChangeEvent<HTMLInputElement>) => setProductName(event.target.value)} placeholder=\"상품명\" /></label>\n            <label><span>가격·할인</span><input value={priceText} onChange={(event: ChangeEvent<HTMLInputElement>) => setPriceText(event.target.value)} placeholder=\"자동 확인 또는 직접 입력\" /></label>\n            <label className={styles.wide}><span>상품 설명·판매 포인트</span><textarea value={productDescription} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => setProductDescription(event.target.value)} placeholder=\"상품 설명과 실제 장점\" /></label>\n            <label className={styles.wide}><span>상품 이미지 주소</span><input value={productImageUrl} onChange={(event: ChangeEvent<HTMLInputElement>) => { setProductImageUrl(event.target.value); setImageLoadFailed(false); }} placeholder=\"자동 저장된 Supabase 이미지 주소 또는 직접 입력\" /></label>\n            <label><span>판매 플랫폼</span><input value={platform} onChange={(event: ChangeEvent<HTMLInputElement>) => setPlatform(event.target.value)} placeholder=\"coupang / temu / naver\" /></label>\n            <label><span>중국어 검색어</span><input value={chineseKeyword} onChange={(event: ChangeEvent<HTMLInputElement>) => setChineseKeyword(event.target.value)} placeholder=\"예: 手持小风扇\" /></label>\n          </div>\n        </div>", "product preview and fallback UI");
writeUtf8(componentPath, component);

let css = normalize(fs.readFileSync(cssPath, "utf8"));
css = replaceOrSkip(css, ".productPreview {\n  display: grid;\n  min-height: 270px;\n  place-items: center;\n  overflow: hidden;\n  border: 1px solid rgba(255,255,255,.08);\n  border-radius: 18px;\n  background: #090e1b;\n}\n.productPreview img { width: 100%; height: 100%; object-fit: contain; }\n.productPreview > div { display: grid; gap: 7px; color: #67748d; text-align: center; }\n.productPreview strong { color: #d5deed; }", ".productPreview {\n  display: grid;\n  min-height: 270px;\n  overflow: hidden;\n  border: 1px solid rgba(255,255,255,.08);\n  border-radius: 18px;\n  background: #090e1b;\n}\n.productPreviewMedia {\n  display: grid;\n  min-height: 214px;\n  place-items: center;\n  overflow: hidden;\n}\n.productPreviewMedia img { width: 100%; height: 100%; max-height: 260px; object-fit: contain; }\n.productPreviewMedia > div { display: grid; gap: 7px; padding: 24px; color: #67748d; text-align: center; }\n.productPreview strong { color: #d5deed; }\n.imageFallbackActions { display: grid; grid-template-columns: 1fr; gap: 7px; padding: 10px; border-top: 1px solid rgba(255,255,255,.07); }\n.imageUploadButton input { display: none; }\n.imageUploadButton span,\n.imageFallbackActions a {\n  display: flex;\n  min-height: 39px;\n  align-items: center;\n  justify-content: center;\n  padding: 0 10px;\n  border-radius: 10px;\n  font-size: 10px;\n  font-weight: 900;\n  text-decoration: none;\n  cursor: pointer;\n}\n.imageUploadButton span { color: #06131a; background: linear-gradient(135deg,#70e7bd,#76c9ff); }\n.imageFallbackActions a { color: #e4ebf7; border: 1px solid rgba(255,255,255,.1); background: rgba(255,255,255,.04); }", "product image styles");
writeUtf8(cssPath, css);

console.log("");
console.log("GY-NEXUS affiliate product image fix V3 was applied.");
console.log(`Backup folder: ${backupRoot}`);
console.log("");
console.log("Next commands:");
console.log("npm run typecheck");
console.log("npm run build");
console.log("git add app/api/revenue-shorts/product-import/route.ts components/revenue-shorts/RevenueShortsCommandCenter.tsx components/revenue-shorts/RevenueShortsCommandCenter.module.css");
console.log('git commit -m "Fix affiliate product image import"');
console.log("git push");
