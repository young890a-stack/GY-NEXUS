# V3.5 Validation Report

검사일: 2026-07-23

## 통과

- 생성 파일 21개 존재 확인
- TypeScript 5.8 strict 합성 프로젝트 구조 검사 통과
- 내부 모듈 경로 `@/*` 기준 확인
- 무의존 ZIP writer 컴파일 및 실제 `unzip -t` 무결성 검사 통과
- ZIP 내부 UTF-8 본문과 중첩 폴더 추출 확인
- 기존 GY-NEXUS 파일 경로와 V3-4 테이블·필드 기준으로 오버레이 구성
- PowerShell 적용 전 기존 대상 파일 자동 백업 포함
- `.env.example` 변경 전 백업 포함
- YouTube 기존 OAuth·업로더를 유지하고 Analytics 읽기 scope만 추가
- 기존 `/admin/learning-engine` 메뉴를 재사용하여 사이드바 중복 방지

## 실제 운영 환경에서 마지막으로 확인할 항목

- Supabase에 `20260723_growth_commerce_v35.sql` 실행
- Vercel에 Canva 환경변수 추가
- YouTube를 다시 연결해 `yt-analytics.readonly` 승인
- `npm run typecheck`와 `npm run build`
- Canva 개발자 앱의 Redirect URI 등록 및 앱 권한 승인 상태

## 제한 사항

현재 ChatGPT 실행 환경의 GitHub App은 저장소 읽기는 가능했지만 새 브랜치 생성이 403으로 차단되어 원격 저장소에 직접 커밋하지 못했습니다. 이를 대신해 기존 프로젝트에 안전하게 덮어쓰는 적용기와 백업 기능을 제공합니다.
