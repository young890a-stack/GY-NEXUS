param(
  [string]$ProjectPath = (Get-Location).Path,
  [switch]$Validate,
  [switch]$Commit
)

$ErrorActionPreference = "Stop"
$BundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Overlay = Join-Path $BundleRoot "overlay"
$ProjectPath = (Resolve-Path $ProjectPath).Path
$PackageJson = Join-Path $ProjectPath "package.json"
if (-not (Test-Path $PackageJson)) { throw "GY-NEXUS 프로젝트 루트에서 실행하거나 -ProjectPath를 지정해주세요." }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $ProjectPath ".gy-backup-v35-$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null

$files = Get-ChildItem -Path $Overlay -Recurse -File
foreach ($file in $files) {
  $relative = $file.FullName.Substring($Overlay.Length).TrimStart([char[]]"\/")
  $target = Join-Path $ProjectPath $relative
  if (Test-Path $target) {
    $backupTarget = Join-Path $backup $relative
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backupTarget) | Out-Null
    Copy-Item $target $backupTarget -Force
  }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
  Copy-Item $file.FullName $target -Force
  Write-Host "[V3.5] $relative" -ForegroundColor Cyan
}

$envExample = Join-Path $ProjectPath ".env.example"
if (Test-Path $envExample) { Copy-Item $envExample (Join-Path $backup ".env.example") -Force }
$envLines = @(
  "",
  "# Growth Commerce Engine V3.5",
  "GOOGLE_TRENDS_RSS_URL=https://trends.google.com/trending/rss?geo=KR",
  "CANVA_CLIENT_ID=",
  "CANVA_CLIENT_SECRET=",
  "CANVA_REDIRECT_URI="
)
if (Test-Path $envExample) {
  $current = Get-Content $envExample -Raw
  if ($current -notmatch "CANVA_CLIENT_ID") { Add-Content -Path $envExample -Value ($envLines -join [Environment]::NewLine) }
}

Write-Host "`nV3.5 파일 적용 완료" -ForegroundColor Green
Write-Host "백업: $backup"
Write-Host "다음: Supabase에서 20260723_growth_commerce_v35.sql 실행"

if ($Validate) {
  Push-Location $ProjectPath
  try {
    if (Test-Path (Join-Path $ProjectPath "node_modules")) {
      npm run typecheck
      if ($LASTEXITCODE -ne 0) { throw "TypeScript 검사 실패" }
      npm run build
      if ($LASTEXITCODE -ne 0) { throw "Next.js 빌드 실패" }
    } else {
      Write-Warning "node_modules가 없어 검사를 건너뜁니다. npm install 후 npm run check를 실행하세요."
    }
  } finally { Pop-Location }
}

if ($Commit) {
  Push-Location $ProjectPath
  try {
    git rev-parse --is-inside-work-tree | Out-Null
    $branch = git branch --show-current
    if ($branch -eq "main" -or $branch -eq "master") { git switch -c "agent/growth-commerce-engine-v35" }
    git add app/admin/learning-engine app/api/growth-commerce app/api/connections/youtube/start app/go components/growth-commerce lib/growth-commerce supabase/migrations .env.example
    git commit -m "Add V3.5 growth commerce engine"
    Write-Host "커밋 완료. 확인 후 git push를 실행하세요." -ForegroundColor Green
  } finally { Pop-Location }
}
