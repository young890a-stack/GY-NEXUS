# GY-NEXUS V3.5 · Growth Commerce Engine

기존 V3-4 쇼츠 제작 엔진의 장점을 유지하고, 제작 이후의 **트렌드 → Canva → CapCut → YouTube → 클릭·판매 → 다음 제작 학습**을 연결하는 덮어쓰기 패치입니다.

## 들어간 기능

- Google Trends 대한민국 급상승 RSS 수집 및 쇼핑 적합도 계산
- YouTube Data API + YouTube Analytics API 성과 동기화
- 조회수뿐 아니라 추적 클릭·구매·매출을 합친 Commerce Score
- 제목 패턴·영상 길이별 판매 학습 규칙
- V3-4 제작안 기반 CapCut 표준 가져오기 ZIP
- Canva OAuth 2.0 PKCE 연결 및 AI 썸네일 편집 디자인 생성
- 영상·콘텐츠별 제휴링크 추적
- 기존 `/admin/learning-engine` 화면을 V3-5 통합 운영센터로 교체

## 가장 쉬운 적용

GY-NEXUS 프로젝트 폴더의 PowerShell에서 다음을 실행합니다.

```powershell
powershell -ExecutionPolicy Bypass -File "압축을 푼 폴더\APPLY-V35.ps1" -Validate
```

그 다음 Supabase SQL Editor에서 아래 파일 전체를 실행합니다.

`overlay/supabase/migrations/20260723_growth_commerce_v35.sql`

## Vercel 환경변수 추가

```text
GOOGLE_TRENDS_RSS_URL=https://trends.google.com/trending/rss?geo=KR
CANVA_CLIENT_ID=
CANVA_CLIENT_SECRET=
CANVA_REDIRECT_URI=https://gy-nexus-zfpq.vercel.app/api/growth-commerce/canva/callback
```

YouTube는 기존 키를 그대로 사용합니다. 다만 Analytics 읽기 권한이 새로 추가되므로 배포 후 **통합 연결센터에서 YouTube 연결을 한 번 해제하고 다시 연결**해야 합니다.

## Canva 개발자 콘솔

Canva 앱의 Redirect URL에 다음을 등록합니다.

`https://gy-nexus-zfpq.vercel.app/api/growth-commerce/canva/callback`

필요 권한:

- `asset:read`
- `asset:write`
- `design:content:write`
- `design:meta:read`
- `profile:read`

## 접속 주소

`https://gy-nexus-zfpq.vercel.app/admin/learning-engine`

## CapCut에 대한 정직한 동작 범위

일반 개발자가 안정적으로 사용하는 CapCut 공개 프로젝트 생성 API가 확인되지 않았기 때문에, 임의의 `.capcut` 파일을 만들지 않습니다. 대신 V3-4 제작안에서 MP4 주소, 정확한 SRT, 대본, 장면표, 썸네일, 제목·설명·해시태그를 ZIP으로 제공해 모바일 CapCut에서 빠르게 최종 수정할 수 있게 합니다.

## Canva에 대한 동작 범위

완성 썸네일의 HTTPS 이미지를 Canva 자산으로 업로드한 후 1080×1920 또는 1280×720 디자인을 생성하고 공식 편집 URL을 엽니다. 최초 1회 Canva 앱 등록과 계정 승인이 필요합니다.
