import { NextResponse } from "next/server";

export async function POST() {
  const response = NextResponse.json({ success: true });
  response.cookies.delete("gy_gsc_token");
  response.cookies.delete("gy_google_token");
  return response;
}
