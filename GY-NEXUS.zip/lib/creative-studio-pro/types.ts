export type ProDuration = 15 | 20 | 25 | 30;
export type ProRatio = "720:1280" | "1280:720";
export type ProStyle = "cinematic-product" | "emotional-brand" | "how-to" | "ugc-review" | "problem-solution";
export type SubtitleMode = "korean" | "none";
export type VoiceMode = "female" | "male" | "music-only" | "silent";
export type ProSourceMode = "single-photo-commerce" | "premium-multi-photo";
export type SubtitleStyle = "bold-pop" | "clean-card" | "minimal";
export type ThumbnailStyle = "benefit-arrow" | "problem-solution" | "clean-product";

export type ProProjectInput = {
  title: string;
  productUrl?: string;
  productName: string;
  productDescription: string;
  masterPrompt: string;
  sourceMode?: ProSourceMode;
  sourceImageUrl?: string;
  referenceImageUrls?: string[];
  duration: ProDuration;
  ratio: ProRatio;
  style: ProStyle;
  subtitleMode: SubtitleMode;
  voiceMode: VoiceMode;
  voicePreset?: "marin" | "coral" | "shimmer" | "cedar" | "onyx" | "echo";
  musicMood: string;
  subtitleStyle?: SubtitleStyle;
  thumbnailStyle?: ThumbnailStyle;
  sfxMode?: "recommended" | "minimal" | "none";
  affiliateUrl?: string;
  platformTargets?: Array<"youtube" | "instagram" | "douyin" | "xiaohongshu">;
  qualityThreshold?: number;
  maxImageRetries?: number;
};

export type SceneQualityStatus =
  | "pending"
  | "generating"
  | "reviewing"
  | "approved"
  | "revision_required"
  | "hold"
  | "failed";

export type SceneImageCandidate = {
  index: number;
  assetUrl: string;
  storagePath?: string;
  score?: number;
  issues?: string[];
};

export type ProductVisualProfile = {
  identitySummary: string;
  category: string;
  dominantColors: string[];
  materials: string[];
  silhouette: string;
  distinctiveFeatures: string[];
  controlsAndPorts: string[];
  visibleBranding: string[];
  includedAccessories: string[];
  forbiddenChanges: string[];
  referenceCoverageScore: number;
  referenceGaps: string[];
};

export type SceneQualityReport = {
  provider: "openai";
  model: string;
  threshold: number;
  score: number;
  approved: boolean;
  summary: string;
  issues: string[];
  metrics: {
    productMatch: number;
    visualIntegrity: number;
    geometryDetail: number;
    colorMaterial: number;
    textLogoIntegrity: number;
    humanAnatomy: number;
    sceneContinuity: number;
    motionReadiness: number;
    commercialNaturalness: number;
    composition: number;
    claimSafety: number;
  };
  criticalErrors: string[];
};

export type PlannedScene = {
  sceneNumber: number;
  startSecond: number;
  endSecond: number;
  duration: 5;
  role: string;
  prompt: string;
  narration: string;
  subtitle: string;
};
